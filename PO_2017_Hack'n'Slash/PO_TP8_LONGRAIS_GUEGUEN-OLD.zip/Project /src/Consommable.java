
public class Consommable extends Item{

	public Consommable(String nom, int x, int y) {
		super(nom, x, y);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void dessine() {
		// TODO Auto-generated method stub
		
	}

}
